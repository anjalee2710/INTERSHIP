export const environments = {
    baseUrl: '',
    key: ''
}