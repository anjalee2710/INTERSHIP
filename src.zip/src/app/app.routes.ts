import { Routes } from '@angular/router';
import { Menu1Component } from './menu1/menu1.component';
import { Menu2Component } from './menu2/menu2.component';

export const routes: Routes = [
//   {
//     path: 'menu-1',
//     component: Menu1Component,
//   },
//   {
//     path: 'menu-2',
//     component: Menu2Component,
//   },
//   { path: '**', redirectTo: 'menu-1' },
];
