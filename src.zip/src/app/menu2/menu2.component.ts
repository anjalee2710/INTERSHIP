import { Component } from '@angular/core';

@Component({
  selector: 'app-menu2',
  standalone: true,
  imports: [],
  templateUrl: './menu2.component.html',
  styleUrl: './menu2.component.css'
})
export class Menu2Component {

}
